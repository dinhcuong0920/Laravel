<?php $__env->startSection('content'); ?>
<!--main-->
<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
    <div class="row">
        <ol class="breadcrumb">
            <li><a href="#"><svg class="glyph stroked home">
                        <use xlink:href="#stroked-home"></use>
                    </svg></a></li>
            <li class="active">Danh sách sản phẩm</li>
        </ol>
    </div>
    <!--/.row-->

    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Danh sách sản phẩm</h1>
        </div>
    </div>
    <!--/.row-->

    <div class="row">
        <div class="col-xs-12 col-md-12 col-lg-12">

            <div class="panel panel-primary">

                <div class="panel-body">
                    <div class="bootstrap-table">
                        <div class="table-responsive">
                            <?php if(session('thongbao')): ?>
                            <div class="alert bg-success" role="alert">
                                    <svg class="glyph stroked checkmark">
                                        <use xlink:href="#stroked-checkmark"></use>
                                    </svg><?php echo e(session('thongbao')); ?><a href="#" class="pull-right"><span
                                            class="glyphicon glyphicon-remove"></span></a>
                            </div>
                            <?php endif; ?>
                            <a href="/admin/product/add" class="btn btn-primary">Thêm sản phẩm</a>
                            <table class="table table-bordered" style="margin-top:20px;">
                                <thead>
                                    <tr class="bg-primary">
                                        <th>ID</th>
                                        <th>Thông tin sản phẩm</th>
                                        <th>Giá sản phẩm</th>
                                        <th>Tình trạng</th>
                                        <th>Danh mục</th>
                                        <th>Tùy chọn</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                    <td><?php echo e($product->id); ?></td>
                                            <td>
                                                <div class="row">
                                                <div class="col-md-3"><img src='/admins/img/<?php echo e($product->img); ?>' alt="Áo đẹp"
                                                            width="100px" class="thumbnail"></div>
                                                    <div class="col-md-9">
                                                        <p><strong>Mã sản phẩm : <?php echo e($product->code); ?></strong></p>
                                                        <p>Tên sản phẩm :<?php echo e($product->name); ?></p>
                                                        <p>Danh mục:<?php echo e($product->category->name); ?></p>
                                                        <?php $__currentLoopData = attr_values($product->values); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <p><?php echo e($key); ?>:
                                                            <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php echo e($item); ?>,
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </p>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </td>
                                            <td><?php echo e($product->price); ?></td>
                                            <td>
                                                <?php if($product->state==1): ?>
                                                <a name="" id="" class="btn btn-success" href="#" role="button">Còn hàng</a>
                                                <?php else: ?>
                                                <a name="" id="" class="btn btn-danger" href="#" role="button">Hết hàng</a>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($product->category->name); ?></td>
                                            <td>
                                            <a href="/admin/product/edit/<?php echo e($product->id); ?>" class="btn btn-warning"><i class="fa fa-pencil"
                                                        aria-hidden="true"></i> Sửa</a>
                                                <a onclick='return Del("<?php echo e($product->name); ?>")' href="/admin/product/del/<?php echo e($product->id); ?>" class="btn btn-danger"><i class="fa fa-trash"
                                                        aria-hidden="true"></i> Xóa</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <div align='right'>
                                <?php echo $products->render('vendor.pagination.default'); ?>

                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>

                </div>
            </div>
            <!--/.row-->
        </div>
        <script>
            function Del(name)
            {   
                return confirm('Bạn có muốn xóa sản phẩm'+ name)
            }
        </script>
        <!--end main-->
		<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fibonacci##\Desktop\laravel\resources\views/backend/product/listproduct.blade.php ENDPATH**/ ?>