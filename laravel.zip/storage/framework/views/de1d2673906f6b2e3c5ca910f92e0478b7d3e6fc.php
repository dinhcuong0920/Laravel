<?php $__env->startSection('content'); ?>

	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><svg class="glyph stroked home">
							<use xlink:href="#stroked-home"></use>
						</svg></a></li>
				<li class="active">Danh mục/Thuộc tính/Sửa thuộc tính</li>
			</ol>
		</div>
		<!--/.row-->

	
		<!--/.row-->
		<div class="row col-md-offset-3 ">
			<div class="col-md-6">	
			<div class="panel panel-blue">
				<div class="panel-heading dark-overlay">Sửa thuộc tính</div>
				<div class="panel-body">
					<form action="" method="POST">
					<?php echo csrf_field(); ?>
					<div class="form-group">
					  <label for="">Tên Thuộc tính</label>
					<input type="text" name="name_attr" id="" class="form-control" value="<?php echo e($attr->name); ?>" placeholder="" aria-describedby="helpId">
				
					</div>
					<div  align="right"><button class="btn btn-success" type="submit">Sửa</button></div>
				</form>
				<?php echo e(CheckErrors($errors,'name_attr')); ?>

				<?php if(session('thongbao')): ?>
					<div class="alert alert-danger" role="alert">
						<strong><?php echo e(session('thongbao')); ?></strong>
					</div>
				<?php endif; ?>
				</div>
			</div>
							
							
							
				
			</div>
			<!--/.col-->
		</div>
		<!--/.row-->
	</div>
	<!--/.main-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fibonacci##\Desktop\vietpro_video\blog\resources\views/backend/product/attr/editattr.blade.php ENDPATH**/ ?>