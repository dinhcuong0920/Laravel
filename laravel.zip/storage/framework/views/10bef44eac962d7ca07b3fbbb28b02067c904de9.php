<?php $__env->startSection('content'); ?>
    <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
        <div class="row">
            <ol class="breadcrumb">
                <li><a href="#"><svg class="glyph stroked home">
                            <use xlink:href="#stroked-home"></use>
                        </svg></a></li>
                <li class="active">Biến thể</li>
            </ol>
        </div>
        <!--/.row-->

        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Biến thể</h1>
            </div>
        </div>
        <!--/.row-->
        <div class="col-md-12">
            <div class="panel panel-default">
            
                    <div class="panel-heading" align='center'>
                        Giá cho từng biến thể sản phẩm : <?php echo e($product->name); ?> (<?php echo e($product->code); ?>)
                    </div>
                    <?php echo e(Alert('thongbao')); ?>

                    <form  method="post">
                        <?php echo csrf_field(); ?>
                    <div class="panel-body" align='center'>
                        <table class="panel-body">
                            <thead>
                                <tr>
                                    <th width='33%'>Biến thể</th>
                                    <th width='33%'>Giá (có thể trống)</th>
                                    <th width='33%'>Tuỳ chọn</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $product->variant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                        <td scope="row">
                                            <?php $__currentLoopData = $variant->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            
                                            <?php echo e($value->attribute->name); ?> : <?php echo e($value->value); ?>,
                                            
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td>
                                            <div class="form-group">
                                                <input name="variant[<?php echo e($variant->id); ?>]" class="form-control" placeholder="Giá cho biến thể" value="">
                                            </div>
                                        </td>
                                        <td>
                                        <a id="" onclick="return Del()" class="btn btn-warning" href="/admin/product/del-variant/<?php echo e($variant->id); ?>" role="button">Xoá</a>
    
                                        </td>
    
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                        </table>

                    </div>
                    <div align='right'><button class="btn btn-success" type="submit"> Cập nhật </button> 
                        <a class="btn btn-warning" href="/admin/product" role="button">Bỏ qua</a></div>
                    </form>
             
            </div>
        </div>

    </div>
    <script>
            function Del()
            {   
                return confirm('Bạn có muốn xóa biến thể')
            }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fibonacci##\Desktop\vietpro_video\blog\resources\views/backend/product/variant/addvariant.blade.php ENDPATH**/ ?>