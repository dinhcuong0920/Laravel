<?php $__env->startSection('content'); ?>

	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><svg class="glyph stroked home">
							<use xlink:href="#stroked-home"></use>
						</svg></a></li>
				<li class="active">Danh mục</li>
			</ol>
		</div>
		<!--/.row-->

		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Quản lý thuộc tính</h1>
				<?php echo e(Alert('thongbao')); ?>

			</div>
		</div>
		<!--/.row-->
		<div class="row">
			<div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-body">
							<?php $__currentLoopData = $attrs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="row magrin-attr">
								<div class="col-md-2 panel-blue widget-left">
									<strong class="large"><?php echo e($attr->name); ?></strong>
									<a onclick="return Del()" class="delete-attr" href="/admin/product/del-attr/<?php echo e($attr->id); ?>"><i class="fas fa-times"></i></a>
								<a class="edit-attr" href="/admin/product/edit-attr/<?php echo e($attr->id); ?>"><i class="fas fa-edit"></i></a>
								</div>
								<div class="col-md-10 widget-right boxattr">
								<?php $__currentLoopData = $attr->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="text-attr"><?php echo e($value->value); ?>

										<a href="/admin/product/edit-value/<?php echo e($value->id); ?>" class="edit-value"><i class="fas fa-edit"></i></a>
										<a  href="#" class="del-value"><i class="fas fa-times"></i></a>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<div class="text-attr"><a href="#" class="add-value"><i class="fas fa-plus-circle"></i></i></a></div>
								
								</div>		
								
						</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
							
							
					</div>
				</div>
			</div>
			<!--/.col-->
		</div>
		<!--/.row-->
	</div>
	<!--/.main-->
	<script>
		function Del()
		{
			return confirm('Bạn có muốn xóa thuộc tính')
		}
		
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fibonacci##\Desktop\vietpro_video\blog\resources\views/backend/product/attr/attr.blade.php ENDPATH**/ ?>