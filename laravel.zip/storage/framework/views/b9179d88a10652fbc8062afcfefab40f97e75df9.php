<?php $__env->startSection('content'); ?>
		<!-- main -->
		<div class="colorlib-shop">
			<div class="container">
				<div class="row row-pb-lg">
					<div class="col-md-10 col-md-offset-1">
						<div class="product-detail-wrap">
							<div class="row">
								<div class="col-md-5">
									<div class="product-entry">
										<div class="product-img" style="background-image: url(/admins/img/<?php echo e($product->img); ?>);">

										</div>

									</div>
								</div>
								<div class="col-md-7">
									<form action="/products/cart" method="get">
										<div class="desc">
											<h3><?php echo e($product->name); ?></h3>
											<p class="price">
											<span><?php echo e(number_format($product->price,0,'','.')); ?></span>
											</p>
											<p>thông tin</p>
											<?php $__currentLoopData = attr_values($product->values); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<div class="size-wrap">
												<p class="size-desc">
													<?php echo e($key); ?>:
													<?php $__currentLoopData = $values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<a class="size"><?php echo e($value); ?></a>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</p>
											</div>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											<h4>Lựa chọn</h4>
											<div class="row">
												<?php $__currentLoopData = attr_values($product->values); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<div class="col-md-3">
													<div class="form-group">
														<label><?php echo e($key); ?>:</label>
														<select class="form-control " name="attr[<?php echo e($key); ?>]" id="">
															<?php $__currentLoopData = $values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($item); ?>"> <?php echo e($item); ?></option>
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														</select>
													</div>
												</div>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


											</div>
											<div class="row row-pb-sm">
												<div class="col-md-4">
													<div class="input-group">
														<span class="input-group-btn">
															<button type="button" class="quantity-left-minus btn" data-type="minus" data-field="">
																<i class="icon-minus2"></i>
															</button>
														</span>
														<input type="text" id="quantity" name="quantity" class="form-control input-number" value="1" min="1" max="100">
														<span class="input-group-btn">
															<button type="button" class="quantity-right-plus btn" data-type="plus" data-field="">
																<i class="icon-plus2"></i>
															</button>
														</span>
													</div>
												</div>
											</div>
										<input type="hidden" name="id_product" value="<?php echo e($product->id); ?>">
											<p><button class="btn btn-primary btn-addtocart" type="submit"> Thêm vào giỏ hàng</button></p>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-10 col-md-offset-1">
						<div class="row">
							<div class="col-md-12 tabulation">
								<ul class="nav nav-tabs">
									<li class="active"><a data-toggle="tab" href="#description">Mô tả</a></li>
								</ul>
								<div class="tab-content">
									<div id="description" class="tab-pane fade in active">
										Đây là sản phẩm đẹp
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="colorlib-shop">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-md-offset-3 text-center colorlib-heading">
						<h2><span>Sản phẩm Mới</span></h2>
					</div>
				</div>
				<div class="row">
					<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-md-3 text-center">
						<div class="product-entry">
							<div class="product-img" style="background-image: url(/admins/img/<?php echo e($product->img); ?>);">
								<p class="tag"><span class="new">New</span></p>
								<div class="cart">
									<p>
										<span class="addtocart"><a href="#"><i class="icon-shopping-cart"></i></a></span>
									<span><a href="/products/detail/<?php echo e($product->id); ?>"><i class="icon-eye"></i></a></span>


									</p>
								</div>
							</div>
							<div class="desc">
								<h3><a href="shop.html"><?php echo e($product->name); ?></a></h3>
								<p class="price"><span><?php echo e(number_format($product->price,0,'','.')); ?> VNĐ</span></p>
							</div>
						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
		</div>
		<!-- end main -->
		
		
		<?php $__env->startSection('script_detail'); ?>
			
			<script>
				$(document).ready(function () {
	
					var quantitiy = 0;
					$('.quantity-right-plus').click(function (e) {
	
						// Stop acting like a button
						e.preventDefault();
						// Get the field name
						var quantity = parseInt($('#quantity').val());
	
						// If is not undefined
	
						$('#quantity').val(quantity + 1);
	
	
						// Increment
	
					});
	
					$('.quantity-left-minus').click(function (e) {
						// Stop acting like a button
						e.preventDefault();
						// Get the field name
						var quantity = parseInt($('#quantity').val());
	
						if (quantity > 0) {
							$('#quantity').val(quantity - 1);
						}
					});
	
				});
			</script>
		<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fibonacci##\Desktop\vietpro_video\blog\resources\views/frontend/product/detail.blade.php ENDPATH**/ ?>